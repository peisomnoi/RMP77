package com.example.mydialer

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.*
import com.google.gson.Gson
import timber.log.Timber
import java.net.HttpURLConnection
import java.net.URL

data class Contact (
    val name: String,
    val phone: String,
    val type:String
)

class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
    val name: TextView = itemView.findViewById(R.id.name)
    val phone: TextView = itemView.findViewById(R.id.phone)
    val type: TextView = itemView.findViewById(R.id.type)

    fun bindTo(data: Contact) {
        name.setText(data.name)
        phone.setText(data.phone)
        type.setText(data.type)

        itemView.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + data.phone))
            ContextCompat.startActivity(itemView.context, intent, null)
        }
    }
}

class Adapter : ListAdapter<Contact, ViewHolder>(ContactDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.rview_item, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = currentList[position]
        holder.bindTo(data)
    }
}

class ContactDiffCallback : DiffUtil.ItemCallback<Contact>() {
    override fun areItemsTheSame(oldItem: Contact, newItem: Contact): Boolean = oldItem == newItem
    override fun areContentsTheSame(oldItem: Contact, newItem: Contact): Boolean = oldItem == newItem
}

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.rView)
        val dividerItemDecoration = DividerItemDecoration(recyclerView.context, DividerItemDecoration.VERTICAL)
        recyclerView.addItemDecoration(dividerItemDecoration)
        val adapter = Adapter()
        val sharedPreferences: SharedPreferences = getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        val savedString = sharedPreferences.getString("SEARCH_FILTER", null)
        val ed_t: EditText = findViewById<EditText>(R.id.search)
        ed_t.setText(savedString)


        var contacts = arrayListOf<Contact>()

        val url = URL("https://drive.google.com/u/0/uc?id=1-KO-9GA3NzSgIc1dkAsNm8Dqw0fuPxcR")
        Thread {
            val urlConnection: HttpURLConnection = url.openConnection() as HttpURLConnection
            var data = ""
            var contacts: ArrayList<Contact>
            try {
                data = urlConnection.inputStream.bufferedReader().readText()
            } finally {
                contacts =
                    Gson().fromJson(data, Array<Contact>::class.java).toList() as ArrayList<Contact>
            }
            urlConnection.disconnect()
            runOnUiThread() {
                recyclerView.layoutManager = LinearLayoutManager(this)
                recyclerView.adapter = adapter
                adapter.submitList(contacts)
            }

            val et = findViewById<EditText>(R.id.search)
            et.addTextChangedListener(object : TextWatcher {

                override fun afterTextChanged(s: Editable) {
                  val txt = et.text.toString()
                  val sharedPreferences: SharedPreferences = getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
                  val editor: SharedPreferences.Editor = sharedPreferences.edit()
                    editor.apply(){
                        putString("SEARCH_FILTER",txt)
                    }.apply()



                }
                override fun beforeTextChanged(s: CharSequence, start: Int,
                                               count: Int, after: Int) {
                }
                override fun onTextChanged(s: CharSequence, start: Int,
                                           before: Int, count: Int) {
                    var contactSearch = arrayListOf<Contact>()
                    val etText = et.text.toString()
                    if (etText != "") {
                        contacts.forEach { qq ->
                            if (etText.contains(qq.name) || etText.contains(qq.phone) || etText.contains(qq.type)) {
                                contactSearch.add(qq)
                            }
                        }
                        runOnUiThread() {
                            adapter.submitList(contactSearch)
                            adapter.notifyDataSetChanged()
                        }
                    } else {
                        runOnUiThread() {
                            adapter.submitList(contacts)
                        }
                    }
                }
            })
        }.start()
    }
}